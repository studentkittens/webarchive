Bitte erst lesen!
=================

Backend: 
--------

  - Dokumentation findet sich in docs/latex_pdf/Webarchive.pdf,
    bzw. die HTML Dokumentation unter docs/html/index.html.
    Wir empfehlen die HTML Dokumentation nach Art des Hauses.

  - Spezifikation wurde nicht mehr angefasst,
    Änderungen/Neuerungen siehe PDF / HTML
    HTML Dokumentation ist auch online verfügbar: 
    http://studentkittens.github.com/webarchive/index.html

  - Der Quelltext kann in source/ besichtigt werden, empfohlen wird zum
    anschauen die GitHub Oberfläche: https://github.com/studentkittens/webarchive 

  - Unittests wurde für sinnvolle Module verfasst; wie bereits beschrieben
    wurde gegenseitig getestet.

  - Modulauthoren stehen in jedem Modul als __author__ = '(Sam Rockwell)' drin.

  - Der Backendquelltext ist, solange nicht anders hingewiesen, unter der GPLv3
    lizensiert. Wir lassen aber auch mit uns reden falls diese zu restriktiv
    wäre.

  - Sam Rockwell ist keine reelle Person, jegliche Ähnlichkeit zu tatsächlichen
    Personen oder Tieren ist rein zufällig und nicht beabsichtigt.
    Es geht uns gut. Trotz Schlangen.

Fronted:
--------

**TODO**
