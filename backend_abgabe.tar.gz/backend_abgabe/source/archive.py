#!/bin/bash
# Just forward commands to python -m archive
env python -m archive $*
