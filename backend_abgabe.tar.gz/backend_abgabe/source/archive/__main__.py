#!/usr/bin/env python
# encoding: utf-8

import archive.cli.cmdparser as c
c.Cli()
