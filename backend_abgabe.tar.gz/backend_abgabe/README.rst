Bitte erst lesen!
=================

Backend: 
--------
  
  - Am Backend haben folgende Personen gearbeitet:

    - Christoph Piechula, #027 46 310 
    - Christopher Pahl,   #012 71 710 
    - Florian Bauer,      #024 13 610 

  - Dokumentation findet sich in docs/latex_pdf/Webarchive.pdf,
    bzw. die HTML Dokumentation unter docs/html/index.html.
    Wir empfehlen die HTML Dokumentation nach Art des Hauses.

  - Spezifikation wurde nicht mehr angefasst,
    Änderungen/Neuerungen siehe PDF / HTML
    HTML Dokumentation ist auch online verfügbar: 
    http://studentkittens.github.com/webarchive/index.html

  - Der Quelltext kann in source/ besichtigt werden, empfohlen wird zum
    anschauen die GitHub Oberfläche: https://github.com/studentkittens/webarchive 

  - Unter gitstats/ findet sich eine (sehr grobe) Übersicht, 
    wer wie oft und wieviel committed hat. Wir fanden es interessant.

  - Unittests wurde für sinnvolle Module verfasst; wie bereits beschrieben
    wurde gegenseitig getestet.

  - Modulauthoren stehen in jedem Modul als __author__ = '(Sam Rockwell)' drin.

  - Der Backendquelltext ist, solange nicht anders hingewiesen, unter der GPLv3
    lizensiert. Wir lassen aber auch mit uns reden falls diese zu restriktiv
    wäre.

  - Unter source/wget_patched findet sich ein gepatchtes Paket für ArchLinux, 
    mit den für uns nötigen IRI support.

  - Sam Rockwell ist keine reelle Person, jegliche Ähnlichkeit zu tatsächlichen
    Personen oder Tieren ist rein zufällig und nicht beabsichtigt.
    Es geht uns gut. Trotz Schlangen.

Fronted:
--------

  - Am Fronted waren folgende Personen beteiligt: 

    - Sabrina Biersack,  #011 67 210 
    - Eduard Schneider,  #025 68 810 
    - Christoph Cwelich, #005 20 710 

**TODO**
