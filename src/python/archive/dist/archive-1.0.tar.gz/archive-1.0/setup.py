from distutils.core import setup

setup(
        name = 'archive',
        version = "1.0",
        packages = ['crawler', 'cmanager', 'javadapter', 'util', 'config', 'cli', 'dbrecover', 'init'],
        url = "www.github.com/studentkittens/webarchive",
        author = "Christopher Pahl, Christoph Piechula",
        author_email = "cpahl@hof-university.de, cpiechula@hof-university.de"
        )
